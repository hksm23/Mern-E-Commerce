import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { signupAsync, selectLoggedInUser, selectSignupStatus, selectSignupError, clearSignupError, resetSignupStatus } from '../AuthSlice';
import { toast } from 'react-toastify';

export const Signup = () => {
  const dispatch = useDispatch();
  const status = useSelector(selectSignupStatus);
  const error = useSelector(selectSignupError);
  const loggedInUser = useSelector(selectLoggedInUser);
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const navigate = useNavigate();

  useEffect(() => {
    if (loggedInUser && !loggedInUser?.isVerified) {
      navigate('/verify-otp');
    } else if (loggedInUser) {
      navigate('/');
    }
  }, [loggedInUser]);

  useEffect(() => {
    if (error) {
      toast.error(error.message);
    }
  }, [error]);

  useEffect(() => {
    if (status === 'fullfilled') {
      toast.success('Welcome! Verify your email to start shopping.');
      reset();
    }
    return () => {
      dispatch(clearSignupError());
      dispatch(resetSignupStatus());
    };
  }, [status]);

  const handleSignup = (data) => {
    const cred = { ...data };
    delete cred.confirmPassword;
    dispatch(signupAsync(cred));
  };

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600">
      <div className="bg-white/10 backdrop-blur-lg p-8 shadow-lg rounded-lg w-full max-w-md border border-white/20">
        <h2 className="text-3xl font-bold text-center text-white mb-4">Create an Account</h2>
        <form className="space-y-4" onSubmit={handleSubmit(handleSignup)}>
          <div>
            <label className="block text-white mb-1">Username</label>
            <input
              type="text"
              {...register("name", { required: "Username is required" })}
              placeholder="Username"
              className="w-full p-3 border border-gray-300 rounded-lg bg-white/30 text-white focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            {errors.name && <p className="text-red-400 text-sm">{errors.name.message}</p>}
          </div>

          <div>
            <label className="block text-white mb-1">Email</label>
            <input
              type="email"
              {...register("email", {
                required: "Email is required",
                pattern: {
                  value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                  message: "Enter a valid email"
                }
              })}
              placeholder="Email"
              className="w-full p-3 border border-gray-300 rounded-lg bg-white/30 text-white focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            {errors.email && <p className="text-red-400 text-sm">{errors.email.message}</p>}
          </div>

          <div>
            <label className="block text-white mb-1">Password</label>
            <input
              type="password"
              {...register("password", {
                required: "Password is required",
                pattern: {
                  value: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/,
                  message: "Password must contain at least 8 characters, including uppercase, lowercase, and a number"
                }
              })}
              placeholder="Password"
              className="w-full p-3 border border-gray-300 rounded-lg bg-white/30 text-white focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            {errors.password && <p className="text-red-400 text-sm">{errors.password.message}</p>}
          </div>

          <div>
            <label className="block text-white mb-1">Confirm Password</label>
            <input
              type="password"
              {...register("confirmPassword", {
                required: "Confirm Password is required",
                validate: (value, formValues) => value === formValues.password || "Passwords don't match"
              })}
              placeholder="Confirm Password"
              className="w-full p-3 border border-gray-300 rounded-lg bg-white/30 text-white focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            {errors.confirmPassword && <p className="text-red-400 text-sm">{errors.confirmPassword.message}</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-green-400 to-blue-500 text-white p-3 rounded-lg font-semibold transition-transform transform hover:scale-105 hover:shadow-lg disabled:opacity-50"
            disabled={status === 'pending'}
          >
            {status === 'pending' ? 'Signing up...' : 'Signup'}
          </button>
        </form>


        <div className="mt-4 text-center">
          <Link to="/forgot-password" className="text-white hover:underline">Forgot password?</Link>
        </div>
        <div className="mt-2 text-center text-white">
          Already a member? <Link to="/login" className="text-green-300 hover:underline">Login</Link>
        </div>
      </div>
    </div>
  );
};
