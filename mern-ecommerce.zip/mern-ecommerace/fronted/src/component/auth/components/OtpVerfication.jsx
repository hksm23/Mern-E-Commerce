import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from "react-hook-form";
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { clearOtpVerificationError, clearResendOtpError, clearResendOtpSuccessMessage, resendOtpAsync, resetOtpVerificationStatus, resetResendOtpStatus, selectLoggedInUser, selectOtpVerificationError, selectOtpVerificationStatus, selectResendOtpError, selectResendOtpStatus, selectResendOtpSuccessMessage, verifyOtpAsync } from '../AuthSlice';

export const OtpVerification = () => {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const dispatch = useDispatch();
    const loggedInUser = useSelector(selectLoggedInUser);
    const navigate = useNavigate();
    const resendOtpStatus = useSelector(selectResendOtpStatus);
    const resendOtpError = useSelector(selectResendOtpError);
    const resendOtpSuccessMessage = useSelector(selectResendOtpSuccessMessage);
    const otpVerificationStatus = useSelector(selectOtpVerificationStatus);
    const otpVerificationError = useSelector(selectOtpVerificationError);

    useEffect(() => {
        if (!loggedInUser) {
            navigate('/login');
        } else if (loggedInUser?.isVerified) {
            navigate("/");
        }
    }, [loggedInUser]);

    const handleSendOtp = () => {
        const data = { user: loggedInUser?._id };
        dispatch(resendOtpAsync(data));
    };
    
    const handleVerifyOtp = (data) => {
        const cred = { ...data, userId: loggedInUser?._id };
        dispatch(verifyOtpAsync(cred));
    };

    useEffect(() => {
        if (resendOtpError) {
            toast.error(resendOtpError.message);
        }
        return () => {
            dispatch(clearResendOtpError());
        };
    }, [resendOtpError]);

    useEffect(() => {
        if (resendOtpSuccessMessage) {
            toast.success(resendOtpSuccessMessage.message);
        }
        return () => {
            dispatch(clearResendOtpSuccessMessage());
        };
    }, [resendOtpSuccessMessage]);

    useEffect(() => {
        if (otpVerificationError) {
            toast.error(otpVerificationError.message);
        }
        return () => {
            dispatch(clearOtpVerificationError());
        };
    }, [otpVerificationError]);

    useEffect(() => {
        if (otpVerificationStatus === 'fullfilled') {
            toast.success("Email verified! We are happy to have you here");
            dispatch(resetResendOtpStatus());
        }
        return () => {
            dispatch(resetOtpVerificationStatus());
        };
    }, [otpVerificationStatus]);

    return (
        <div className="flex flex-col items-center justify-center h-screen w-screen bg-gray-100">
            <div className="bg-white shadow-md p-8 rounded-lg w-96">
                <h2 className="text-xl font-semibold text-center mb-4">Verify Your Email Address</h2>
                {resendOtpStatus === 'fullfilled' ? (
                    <form onSubmit={handleSubmit(handleVerifyOtp)} className="space-y-4">
                        <div>
                            <p className="text-gray-600 text-sm">Enter the 4-digit OTP sent to</p>
                            <p className="font-semibold text-gray-800">{loggedInUser?.email}</p>
                        </div>
                        <div>
                            <input {...register("otp", { required: "OTP is required", minLength: { value: 4, message: "Please enter a 4-digit OTP" } })} type='number' className="w-full border rounded-md p-2" placeholder="Enter OTP"/>
                            {errors?.otp && <p className="text-red-500 text-sm mt-1">{errors.otp.message}</p>}
                        </div>
                        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200" disabled={otpVerificationStatus === 'pending'}>
                            {otpVerificationStatus === 'pending' ? 'Verifying...' : 'Verify'}
                        </button>
                    </form>
                ) : (
                    <>
                        <div className="text-center">
                            <p className="text-gray-600 text-sm">We will send you an OTP on</p>
                            <p className="font-semibold text-gray-800">{loggedInUser?.email}</p>
                        </div>
                        <button onClick={handleSendOtp} className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition duration-200" disabled={resendOtpStatus === 'pending'}>
                            {resendOtpStatus === 'pending' ? 'Sending OTP...' : 'Get OTP'}
                        </button>
                    </>
                )}
            </div>
        </div>
    );
};