import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export const ProductCard = ({ id, title, price, thumbnail, brand }) => {
    const navigate = useNavigate();

    return (
        <div 
            className="p-4 shadow-md rounded-md cursor-pointer w-64" 
            onClick={() => navigate(`/product-details/${id}`)}
        >
            {/* Image */}
            <div className="w-full h-64 flex justify-center items-center">
                <img 
                    className="w-full h-full object-contain" 
                    src={thumbnail} 
                    alt={`${title} photo unavailable`} 
                />
            </div>

            {/* Product Info */}
            <div className="mt-4 space-y-2">
                <h3 className="text-lg font-semibold">{title}</h3>
                <p className="text-gray-500">{brand}</p>
                <p className="text-xl font-bold">${price}</p>
            </div>
        </div>
    );
};
