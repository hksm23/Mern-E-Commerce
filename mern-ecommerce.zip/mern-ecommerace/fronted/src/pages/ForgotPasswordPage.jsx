import React from 'react'
import { ForgotPassword } from '../component/auth/components/ForgotPassword'

export const ForgotPasswordPage = () => {
  return (
    <ForgotPassword/>
  )
}
