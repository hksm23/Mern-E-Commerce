import React from 'react'
import { Login } from '../component/auth/components/Login'

export const LoginPage = () => {
  return (
    <Login/>
  )
}
