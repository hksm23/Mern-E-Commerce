import React from 'react'
import { OtpVerification } from '../component/auth/components/OtpVerfication'

export const OtpVerificationPage = () => {
  return (
    <OtpVerification/>
  )
}
