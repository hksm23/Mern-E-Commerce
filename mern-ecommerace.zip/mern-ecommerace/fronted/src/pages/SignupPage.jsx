import React from 'react'
import { Signup } from '../component/auth/components/Signup'

export const SignupPage = () => {
  return (
    <Signup/>
  )
}
