import React from 'react'
import { ResetPassword } from '../component/auth/components/ResetPassword'

export const ResetPasswordPage = () => {
  return (
    <ResetPassword/>
  )
}
